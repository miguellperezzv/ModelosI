package personajes;

import java.awt.Image;

import javax.swing.ImageIcon;

public abstract class Escudo {
	
	//int escudo;
	
	public abstract void crearEscudo();
	public abstract ImageIcon mostrarEscudo();
}
