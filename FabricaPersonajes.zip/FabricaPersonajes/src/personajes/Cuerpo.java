package personajes;

import javax.swing.ImageIcon;

public abstract class Cuerpo {
	
	public abstract void crearCuerpo();
	public abstract ImageIcon mostrarCuerpo();
}
