package personajes;

import java.awt.Component;
import java.awt.Image;

import javax.swing.ImageIcon;

public abstract class Arma {
		
	public ImageIcon Arma;
	
	public abstract void cargarArma();
	public abstract ImageIcon mostrarArma();

}
