package personajes;

public class HCaballero extends Hombre {

	@Override
	public int MostrarFuerza() {
		// TODO Auto-generated method stub
		return 60;
	}

	@Override
	public int MostrarResistencia() {
		// TODO Auto-generated method stub
		return 50;
	}

	@Override
	public int MostrarEstrategia() {
		// TODO Auto-generated method stub
		return 60;
	}



}
