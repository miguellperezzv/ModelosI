package personajes;

public class HRey extends Hombre {

	@Override
	public int MostrarFuerza() {
		// TODO Auto-generated method stub
		return 20;
	}

	@Override
	public int MostrarResistencia() {
		// TODO Auto-generated method stub
		return 10;
	}

	@Override
	public int MostrarEstrategia() {
		// TODO Auto-generated method stub
		return 80;
	}

}
