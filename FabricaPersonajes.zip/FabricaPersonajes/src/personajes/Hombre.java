package personajes;

public abstract class Hombre {
	
	int Fuerza=0;
	int Resistencia=0;
	int Estrategia =0;
	
	public abstract int MostrarFuerza();
	public abstract int MostrarResistencia();
	public abstract int MostrarEstrategia();

}
