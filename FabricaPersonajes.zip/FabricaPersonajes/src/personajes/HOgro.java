package personajes;

public class HOgro extends Hombre{

	@Override
	public int MostrarFuerza() {
		// TODO Auto-generated method stub
		return 100;
	}

	@Override
	public int MostrarResistencia() {
		// TODO Auto-generated method stub
		return 90;
	}

	@Override
	public int MostrarEstrategia() {
		// TODO Auto-generated method stub
		return 10;
	}

}
