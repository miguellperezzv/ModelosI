import java.util.Scanner;

import fabricas.crearCaballero;
import fabricas.crearHechicero;
import fabricas.crearOgro;
import fabricas.crearPersonajeAbstracto;
import personajes.Arma;
import personajes.Escudo;

public class Principal {
	
	
	
	public static void main(String[] args){
		// TODO Auto-generated method stub
		Frame f = new Frame(); 
			
	

}}
